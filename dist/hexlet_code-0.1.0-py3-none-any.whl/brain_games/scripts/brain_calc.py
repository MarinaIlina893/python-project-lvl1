from brain_games.games import calc
from brain_games import game


def main():
    game.run_game(calc)


if __name__ == '__main__':
    main()
